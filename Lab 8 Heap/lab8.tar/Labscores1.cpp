//Christian Eaves
//lab 8: Maps, classes, and everything inbetween.
//Program uses maps, classes overloaded operators, command line args, etc to read and
//sort student names, and lab scores.
#include<iostream>
#include<vector>
#include<cstring>
#include<map>
#include<numeric>
#include<fstream>
#include<string>
#include<iomanip>
#include<algorithm>
#include<utility>
#include<sstream>
using namespace std;

class name_t {
	public:
		name_t(string& fname, string& lname);
		bool operator<(const name_t&) const;
		void print_name(int length) const;
	private:
		string firstname, lastname;
};

class labscores_t {
	public:
		void add_data(int);
		void set_stats();
		void print_labscores() const;
	private:
		vector<int> scores;
		float mean;
		int median;
};

typedef map<name_t, labscores_t> mymap_t;
typedef mymap_t::iterator myit_t;


//Name_t functions
name_t::name_t(string& fname, string& lname){
	firstname = fname;
	lastname = lname;
}

bool name_t::operator<(const name_t& name) const{
	string s;
	s = lastname +  ", " + firstname;

	if(s < (name.lastname + ", " + name.firstname))
		return true;
	return false;
}

void name_t::print_name(int length) const{
	string s = lastname + ", " + firstname;
	cout << setw(length+2) << setfill('.') << left << s;
}
//Labscores_t functions
void labscores_t::add_data(int data){
	scores.push_back(data);
}
//Computes median and mean
void labscores_t::set_stats(){
	sort(scores.begin(), scores.end());
	mean = (float)accumulate(scores.begin(), scores.end(), 0)/scores.size();
	median = scores[(scores.size()-1)/2];
	
}
//Prints labscores
void labscores_t::print_labscores() const{
	for(int i = 0; i < (int)scores.size(); i++){
		cout << right << setw(3) << setfill(' ') << scores[i];
	}
	cout << " : " << median << setprecision(1) << fixed << " " << mean << endl;
}



//mymap_t m;
//
// accumulate(scores.begin(), scores.end(), 0) (STL)
// sort function (STL)
//string s = lastname + ", " firstname;

int main(int argc, char* argv[]){
	ifstream infile;
	string fn, ln, s;
	stringstream ss;
	int temp, max = 0;
	mymap_t m;
	//Making sure the arguments match what the prompts are supposed to be
	if(argc != 3 || strcmp(argv[1], "-byname")){
		cerr << "Usage: ./labscores -byname|byrank|top10 datafile.txt" << endl;
		return -1;
	}


	infile.open(argv[2]);
	//read in data if the file was opened sucessfully
	if(!infile){
		cout << "Could not open scores file." << endl;
	}else{
		//Reading in student data from each line of the text file
		while(getline(infile, s)){
			ss << s;
			ss >> fn >> ln;

			name_t Student(fn, ln);

			if(max < (int)(ln + ", " + fn).length()){
				max = (int)(ln + ", " + fn).length();
			}	

			labscores_t scoredata;
			while(ss >> temp){
				scoredata.add_data(temp);
			}
			ss.clear();
			scoredata.set_stats();
			m.insert(make_pair(Student, scoredata));
		}
	}

	//Stop on your right foot, DONT FORGET IT!
	infile.close();
	
	//Outputting data
	for(map<name_t, labscores_t>::iterator it = m.begin(); it != m.end(); it++){
		it -> first.print_name(max);
		it -> second.print_labscores();
	}
}
